import easyocr
from googletrans import Translator
import json
from difflib import SequenceMatcher

reader = easyocr.Reader(['ar'])


def similar(a, b):
    return SequenceMatcher(None, a, b).ratio()


words = ["اربيل",
         "الانبار",
         "بابل",
         "بغداد",
         "البصرة",
         "حلبجة",
         "دهوك",
         "القادسية",
         "ديالى",
         "ذي قار",
         "السليمانية",
         "صلاح الدين",
         "كركوك",
         "كربلاء",
         "المثنى",
         "ميسان",
         "النجف",
         "نينوى",
         "واسط",
         "خصوصي",
         "فحص",
         "العراق",
         "اجرة",
         "حمل"]


def AssignWord(wrd):
    bestMatch = ""
    prevPrec = 0.0
    for preDefinedWord in words:
        precision = similar(wrd, preDefinedWord)

        if((precision > prevPrec) and (precision > 0.2)):
            bestMatch = preDefinedWord
            prevPrec = precision

    return bestMatch


def ReadLic(img):
    thisdict = {
        "number": "",
        "state": "",
        "city": "",
        "code": ""
    }

    allData = reader.readtext(img)
    print(reader.readtext(img))

    punk = []
    for det in allData:
        punk.append(det[1])
        try:
            translator = Translator()
            ar = translator.translate(str(det[1]), src='ar', dest='en').text
            if (ar.isnumeric()):
                thisdict["number"] = ar
            else:
                thisdict["city"] = ar
        except:
            if (len(det[1]) < 2):
                thisdict["code"] = AssignWord(str(det[1]))
            else:
                if(thisdict["state"] == ""):
                    thisdict["state"] = AssignWord(str(det[1]))
                elif (thisdict["city"] == ""):
                    thisdict["city"] = AssignWord(str(det[1]))
                
            #ar = ar

    print(thisdict)

    return punk
