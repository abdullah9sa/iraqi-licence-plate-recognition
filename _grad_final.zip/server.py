from turtle import title
from flask import Flask, render_template, request, send_file,Blueprint
import detect_plate
from werkzeug.utils import secure_filename
import os
from PIL import Image
import numpy as np
import io
from io import StringIO ,BytesIO
import base64
app = Flask(__name__)


@app.route('/')
def index():
    #data = detect_plate.Detect_Plate()
    # str(data) #'Web App with Python Flask!'
    return render_template('pic.html' , title = "Image Rec.")

@app.route('/video')
def vid():
    #data = detect_plate.Detect_Plate()
    # str(data) #'Web App with Python Flask!'
    return render_template('video.html', title = "Video Rec.")

@app.route('/about')
def abt():
    #data = detect_plate.Detect_Plate()
    # str(data) #'Web App with Python Flask!'
    return render_template('about.html', title = "About")


@app.route('/excute', methods=['GET', 'POST'])
def exc():
    f = request.files['image']
    img = Image.open(f)
    result = detect_plate.Detect_Plate(img)

    def serve_pil_image(pil_img):
        img_io = io.BytesIO()
        pil_img.save(img_io, 'JPEG', quality=70)
        img_io.seek(0)
        return send_file(img_io, mimetype='image/jpeg')


    fm = serve_pil_image(result)
    return fm


app.run(host='0.0.0.0', port=81, debug=True)

